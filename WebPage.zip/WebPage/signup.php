

<html>

<head> 
	<title>Sign Up </title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

	<body>
		

		<div class="header" >
				
				<ul >
				<li><a href="signin.php"><h3 align="center"><h4>Sign In</h4> </a></li>
				<li><a href="index.html"><h3 align="center"><h4>Reload</h4> </a></li>
				</ul>
		</div>
		
		 <div class="free">
		 		<marquee><h3>Welcome My WebSite</h3></marquee>
		</div>
		
		<div class="maincontent">
			<div class="fr">
				
			</div>
			<div class="left" align="center">
				<marquee><img src="4.jpg"></marquee>
			</div>

			<div class="right">

				<form align="center" method="POST" action="/WebPage/signup_action.php">
					
					First Name : <br> <input type="text" name="fname"><br><br>
					Last Name : <br> <input type="text" name="lname"><br><br>
					EMail : <br> <input type="text" name="email"><br><br>
					User Name : <br> <input type="text" name="uname"><br><br>
					Password : <br> <input type="password" name="password"><br><br>
					ConFirm Password : <br> <input type="password" name="password1"><br><br>
					Phone :<br> <input type="text" name="Phone"><br><br>
					Gender : <input type="radio" name="gender" value="male" > Male
							 <input type="radio" name="gender" value="female"> Female
							 <input type="radio" name="gender" value="other"> Other<br><br>
							 
					Date Of Birth : <input type="date"  name="datee" value="29/1/2018"><br><br>
					
					<br><input type="submit" value="click">
				
				</form>
			</div>

		</div>

	</body>

</html>