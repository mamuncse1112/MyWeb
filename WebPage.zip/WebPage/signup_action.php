
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>		


	<div>
				
				<ul  class="header" style="list-style-type:none">
					
				</ul>
		</div>
		

	<?php
	
	$servername = "localhost";
	$username = "root";
	$password = "12345";
	$dbname = "logindb";
	

	$conn =  new mysqli($servername, $username, $password, $dbname);


	$firstname=$_POST['fname'];
	$lastname=$_POST['lname'];
	$name=$firstname.$lastname;


	$email=$_POST['email'];
	$uname=$_POST['uname'];
	$password=$_POST['password'];
	$cpassword=$_POST['password1'];
	$phone=$_POST['Phone'];
	$gender=$_POST['gender'];

	$time = strtotime($_POST['datee']);

	if ($time==false) {
		echo 'Invalid Date: ' . $_POST['datee'];
	}
	else if($password!=$cpassword) {
		echo "Does not match Password";
	}


	else if ($time != false && $password==$cpassword){
  		$new_date = date('Y-m-d', $time);
  		$sql = "INSERT INTO logininfo values ('$name' , '$email','$uname','$password','$phone','$gender','$new_date')";
  		if ($conn->query($sql)==true) {
  			echo "Your Account has Successfully Created....";
  		}else {
  			echo "Some Wrong Information....";
  		}
	}


	

?>
	
	<div class="middle" >
			
				<a href="signup.php"><h1 align="center">Sign Up</h1> </a>
				<a href="signin.php"><h1 align="center">Sign In</h1> </a>
				<a href="index.html"><h1 align="center">Reload</h1> </a>
			</div>
<div class="footer">
		
		</div>
</body>
</html>



