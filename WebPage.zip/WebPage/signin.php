

<html>

<head> 
	<title>Sign Up </title>
	<link rel="stylesheet" type="text/css" href="stylee.css">
</head>

	<body>

	<section class="container">
    <div class="login">
      <h1>Please Enter Your Correct User Name And Password</h1>
      
      <form method="POST" action="/WebPage/signin_action.php">
        <p><input type="text" name="loginn" value="" placeholder="Username or Email"></p>
        <p><input type="password" name="passwordd" value="" placeholder="Password"></p>
        <p class="submit"><input type="submit" name="commit" value="Login"></p>
      </form>

    </div>
  </section>
	
	</body>

</html>