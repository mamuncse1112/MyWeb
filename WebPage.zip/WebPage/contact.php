
<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>		


	<div>
				
				<ul  class="header" style="list-style-type:none">
					<li><h3><a href="#">Search</h3></a></li>
					<li><h3><a href="contact.php">Contacts</h3></a></li>
					<li><h3><a href="index.html">LogOut</h3></a></li>
					<li><h3><a href="#">Sports</h3></a></li>
					
					<li class="dropdown"><h3><a href="#">News</h3>
						<div class="dropdown-content">
							<a href="http://www.prothomalo.com/">Prothom-Alo</a>
							<a href="https://bangla.bdnews24.com/">Bd News</a>
							<a href="http://www.kalerkantho.com/">Kaler Kantha</a>
							<a href="http://www.jugantor.com/">Jugantor</a>
							<a href="http://www.dailynayadiganta.com/">Naya Diganta</a>
							<a href="http://www.dailyjanakantha.com/">Jana Kantha</a>
							<a href="http://www.djanata.com/">Daynik Janata</a>
							<a href="http://www.thedailystar.net/">Dayly Star</a>
						</div>

					<li><h3><a href="Home.html">Home</h3></a></li>
					
				</ul>
		</div>
		
			
		<div>
			
			<script language="JavaScript">
				var i = 0;
				var path = new Array();
 
// LIST OF IMAGES
			path[0] = "1.jpg";
			path[1] = "2.jpg";
			path[2] = "3.jpg";
			path[3]	= "4.jpg";
			path[4] = "5.jpg";

			function swapImage(){
				 document.slide.src = path[i];
   				 if(i < path.length - 1) i++; else i = 0;
   				 setTimeout("swapImage()",10000);
			}
			window.onload=swapImage;
			</script>
		<marquee><img height="70%" name="slide" src="1.jpg" width="70%" align="center" /></marquee>

		</div>

		<div>
			<table border="5px">
				<tr>
						<th>Name</th>
						<td>Md. Mamun Or Rashid</td>
				</tr>

			</table>


		</div>


</body>
</html>



