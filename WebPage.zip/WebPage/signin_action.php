
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>		


	<div>
				
				<ul  class="header" style="list-style-type:none">
					<li><h3><a href="#">Search</h3></a></li>
					<li><h3><a href="contact.php">Contacts</h3></a></li>
					<li><h3><a href="index.html">LogOut</h3></a></li>
					<li><h3><a href="#">Sports</h3></a></li>
					
					<li class="dropdown"><h3><a href="#">News</h3>
						<div class="dropdown-content">
							<a href="http://www.prothomalo.com/">Prothom-Alo</a>
							<a href="https://bangla.bdnews24.com/">Bd News</a>
							<a href="http://www.kalerkantho.com/">Kaler Kantha</a>
							<a href="http://www.jugantor.com/">Jugantor</a>
							<a href="http://www.dailynayadiganta.com/">Naya Diganta</a>
							<a href="http://www.dailyjanakantha.com/">Jana Kantha</a>
							<a href="http://www.djanata.com/">Daynik Janata</a>
							<a href="http://www.thedailystar.net/">Dayly Star</a>
						</div>

					<li><h3><a href="Home.html">Home</h3></a></li>
					
				</ul>
		</div>
		

	<?php
	
	$servername = "localhost";
	$username = "root";
	$password = "12345";
	$dbname = "logindb";
	

	$conn =  new mysqli($servername, $username, $password, $dbname);

	$login=$_POST['loginn'];
	$logpassword=$_POST['passwordd'];


	$sql="select uname, password from logininfo where uname='".$login."' AND password='".$logpassword."' ";

 
	$result = ($conn->query($sql));

	
	if ($result->num_rows == 1) 
	{
		echo "<a href=Home.php>Go</a>";
 
	} 
	else 
	{
	   echo "<h1>Invalid User Name Or Password</h1>"; 
       echo "<a href=signin.php>Login Again</a>" ;
	}

		

?>
	

<div class="footer">
		
		</div>
</body>
</html>



